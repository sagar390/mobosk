package attendance.netsurf.netsurfattendance.models;

public class GetLeaveCompoffCount {


    public static class Request {

        /*{"Emp_Id":"280"}*/

        private String Emp_Id;

        public String getEmp_Id() {
            return Emp_Id;
        }

        public void setEmp_Id(String Emp_Id) {
            this.Emp_Id = Emp_Id;
        }




    }
    public static class Response {


        private int IsLeaveApprover;
        private int LeaveCount;
        private int CompoffCount;

        public int getIsLeaveApprover() {
            return IsLeaveApprover;
        }

        public void setIsLeaveApprover(int isLeaveApprover) {
            IsLeaveApprover = isLeaveApprover;
        }

        public int getLeaveCount() {
            return LeaveCount;
        }

        public void setLeaveCount(int leaveCount) {
            LeaveCount = leaveCount;
        }

        public int getCompoffCount() {
            return CompoffCount;
        }

        public void setCompoffCount(int compoffCount) {
            CompoffCount = compoffCount;
        }
/*[
    {
        "IsLeaveApprover": 1,
        "LeaveCount": 0,
        "CompoffCount": 0
    }
]*/

    }
}
