package attendance.netsurf.netsurfattendance;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import java.util.ArrayList;
import java.util.List;

import attendance.netsurf.netsurfattendance.models.LoggedInUser;
import butterknife.BindView;
import butterknife.ButterKnife;
import rx.Observable;
import rx.Observer;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import timber.log.Timber;

public class LoginActivity extends AppCompatActivity {

    private Observable<ArrayList<LoggedInUser.Response>> observableadvertise;
    Subscription subscription;


    @BindView(R.id.login_username)
    EditText edit_username;


    @BindView(R.id.login_password)
    EditText edit_password;


    @BindView(R.id.img_login)
    RelativeLayout btn_login;


    @BindView(R.id.progressBar_login)
    ProgressBar progressBar;



    private String mLoginId = "";
    private String mPassword = "";
    SharedPreferences pref;
        SharedPreferences.Editor editor;

    public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);
        checkAndRequestPermissions();
        pref = getApplicationContext().getSharedPreferences("Attendance", 0);

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                mLoginId = edit_username.getText().toString().trim();
                mPassword = edit_password.getText().toString().trim();
                boolean valid = true;
                if (mLoginId.isEmpty()) {
                    edit_username.setError("Please enter Username");
                    valid = false;
                } else {
                    edit_username.setError(null);
                }

                if (mPassword.isEmpty()) {
                    edit_password.setError("Please enter Password");
                    valid = false;
                } else {
                    edit_password.setError(null);
                }


                if(valid)
                {
                    progressBar.setVisibility(View.VISIBLE);
                    startLoginProcedure1(mLoginId,mPassword);

                }


            }
        });
    }




    private  boolean checkAndRequestPermissions() {
        int camera = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE);
        int storage = ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int loc = ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION);
        int loc2 = ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION);
        List<String> listPermissionsNeeded = new ArrayList<>();

        if (camera != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(android.Manifest.permission.READ_PHONE_STATE);
        }
        if (storage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (loc2 != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(android.Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (loc != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(android.Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        if (!listPermissionsNeeded.isEmpty())
        {
            ActivityCompat.requestPermissions(this,listPermissionsNeeded.toArray
                    (new String[listPermissionsNeeded.size()]),REQUEST_ID_MULTIPLE_PERMISSIONS);
            return false;
        }
        return true;
    }

    private void startLoginProcedure1(final String uname,final String Pwd) {


        UsApiInterface netsurfApiInterface = NetsurfApiClient.getApiClient(this, true);

        //  progressWheel.setVisibility(android.view.View.VISIBLE);
        if (netsurfApiInterface != null) {
            LoggedInUser.Request logReq = new LoggedInUser.Request();
            logReq.setLoginid(uname);
            logReq.setPassword(Pwd);
            //  logReq.setRoleID(9);
            observableadvertise = netsurfApiInterface.login(logReq);
            subscription = observableadvertise.subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Observer<ArrayList<LoggedInUser.Response>>() {

                        @Override
                        public void onCompleted() {
                            progressBar.setVisibility(View.INVISIBLE);

                        }

                        @Override
                        public void onError(Throwable e) {
                       //     progressWheel.setVisibility(android.view.View.GONE);
                            progressBar.setVisibility(View.INVISIBLE);

                            try {
                                android.widget.Toast.makeText(LoginActivity.this, "Login Failed "+e.getMessage(), android.widget.Toast.LENGTH_LONG).show();
                            } catch (NullPointerException ex) {
                                Timber.i("error while setting data not available  %s ",
                                        "" + ex.getMessage());
                            } catch (IllegalStateException ex) {
                                Timber.i("error while setting data not available  %s ",
                                        "" + ex.getMessage());
                            }
                        }

                        @Override
                        public void onNext(java.util.ArrayList<LoggedInUser.Response>
                                                   respons) {

                            progressBar.setVisibility(View.INVISIBLE);

                         //   progressWheel.setVisibility(android.view.View.GONE);



                


                            if (respons.get(0).getName() != null || respons.get(0).getOfficeId() != 0)
                            {

                                android.widget.Toast.makeText(LoginActivity.this, "Login Success ", android.widget.Toast.LENGTH_LONG).show();

                                SharedPreferences.Editor editor = pref.edit();

                                editor.putInt("CompId", respons.get(0).getCompId()); // Storing string

                                editor.putInt("EmployeeId", respons.get(0).getEmployeeId()); // Storing string

                                editor.putInt("OfficeId", respons.get(0).getOfficeId()); // Storing string

                                editor.putString("UserType", respons.get(0).getUserType()); // Storing string
                                
                                editor.putBoolean("Active", respons.get(0).isActive()); // Storing string
                                
                                editor.putBoolean("IsPoliciesAccepted", respons.get(0).isPoliciesAccepted()); // Storing string

                                editor.putString("LoginId", respons.get(0).getLoginId()); // Storing string
                                
                                editor.putString("Name", respons.get(0).getName()); // Storing string

                                editor.putString("IsReporty", respons.get(0).getIsReporty()); // Storing string

                                editor.putString("Username", uname); // Storing string


                                editor.putString("Password", Pwd); // Storing string



                                editor.commit();

                                android.content.Intent intent = new android.content.Intent(LoginActivity.this, ProfileDashBoardActivity.class);
                                startActivity(intent);
                                finish();


                            } else {
                                android.widget.Toast.makeText(LoginActivity.this, "Login Failed" , android.widget.Toast.LENGTH_LONG).show();

                            }
                        }
                    });

        } else {
            //  android.widget.Toast.makeText(AdvertiseActivity.this, "web url is", android.widget.Toast.LENGTH_LONG).show();
        }

    }

}


