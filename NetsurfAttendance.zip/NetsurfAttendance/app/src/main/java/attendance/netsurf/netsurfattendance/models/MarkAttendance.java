package attendance.netsurf.netsurfattendance.models;

public class MarkAttendance {




    public static class Request {

        private String EmployeeID;
        private String IsWorking;
        private String latitude;
        private String longitude;
        private String UserLocation;
        private String UserRemarks;
        private String ActualMapLocation;

        public String getEmployeeID() {
            return EmployeeID;
        }

        public void setEmployeeID(String employeeID) {
            this.EmployeeID = employeeID;
        }

        public String getIsWorking() {
            return IsWorking;
        }

        public void setIsWorking(String isWorking) {
            this.IsWorking = isWorking;
        }

        public String getLatitude() {
            return latitude;
        }

        public void setLatitude(String latitude) {
            this.latitude = latitude;
        }

        public String getLongitude() {
            return longitude;
        }

        public void setLongitude(String longitude) {
            this.longitude = longitude;
        }

        public String getUserLocation() {
            return UserLocation;
        }

        public void setUserLocation(String userLocation) {
            this.UserLocation = userLocation;
        }

        public String getUserRemarks() {
            return UserRemarks;
        }

        public void setUserRemarks(String userRemarks) {
            this.UserRemarks = userRemarks;
        }

        public String getActualMapLocation() {
            return ActualMapLocation;
        }

        public void setActualMapLocation(String actualMapLocation) {
            this.ActualMapLocation = actualMapLocation;
        }



    }



    public static class Response {



        /*[
    {
        "Retu_Value": 1,
        "Retu_message": "Attandance for Date:- 17 Jul 2019 Recorded as Absent"
    }
]*/

        private int Retu_Value;

        public int getRetu_Value() {
            return Retu_Value;
        }

        public void setRetu_Value(int retu_Value) {
            this.Retu_Value = retu_Value;
        }

        public String getRetu_message() {
            return Retu_message;
        }

        public void setRetu_message(String retu_message) {
            this.Retu_message = retu_message;
        }

        private String Retu_message;

    }

}
