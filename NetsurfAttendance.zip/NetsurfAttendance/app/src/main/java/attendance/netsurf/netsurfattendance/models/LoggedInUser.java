package attendance.netsurf.netsurfattendance.models;

/**
 * Created by chetan on 15/05/15.
 */

public class LoggedInUser

{
    public static class Request {

        /*{"loginid":"280","password":"123"}*/

        private String loginid;

        public String getLoginid() {
            return loginid;
        }

        public void setLoginid(String loginid) {
            this.loginid = loginid;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        private String password;





    }
    public static class Response {


        private int CompId;
        private int EmployeeId;
        private int OfficeId;
        private String UserType;
        private boolean Active;
        private boolean IsPoliciesAccepted;
        private String LoginId;
        private String Name;
        private String IsReporty;

        public int getCompId() {
            return CompId;
        }

        public void setCompId(int compId) {
            this.CompId = compId;
        }

        public int getEmployeeId() {
            return EmployeeId;
        }

        public void setEmployeeId(int employeeId) {
            this.EmployeeId = employeeId;
        }

        public int getOfficeId() {
            return OfficeId;
        }

        public void setOfficeId(int officeId) {
            this.OfficeId = officeId;
        }

        public String getUserType() {
            return UserType;
        }

        public void setUserType(String userType) {
            this.UserType = userType;
        }

        public boolean isActive() {
            return Active;
        }

        public void setActive(boolean active) {
            this.Active = active;
        }

        public boolean isPoliciesAccepted() {
            return IsPoliciesAccepted;
        }

        public void setPoliciesAccepted(boolean policiesAccepted) {
            this.IsPoliciesAccepted = policiesAccepted;
        }

        public String getLoginId() {
            return LoginId;
        }

        public void setLoginId(String loginId) {
            this.LoginId = loginId;
        }

        public String getName() {
            return Name;
        }

        public void setName(String name) {
            this.Name = name;
        }

        public String getIsReporty() {
            return IsReporty;
        }

        public void setIsReporty(String isReporty) {
            this.IsReporty = isReporty;
        }

        public String getPwd() {
            return Pwd;
        }

        public void setPwd(String pwd) {
            this.Pwd = pwd;
        }

        public String getLastmodified() {
            return lastmodified;
        }

        public void setLastmodified(String lastmodified) {
            this.lastmodified = lastmodified;
        }

        public int getIsOnProbession() {
            return IsOnProbession;
        }

        public void setIsOnProbession(int isOnProbession) {
            this.IsOnProbession = isOnProbession;
        }

        private String Pwd;
        private String lastmodified;
        private int IsOnProbession;


   /* [
  [
    {
        "CompId": 1,
        "EmployeeId": 280,
        "LoginId": "280",
        "Pwd": "123",
        "UserType": "Employee",
        "Active": true,
        "Name": "Employee Test Prakash",
        "IsPoliciesAccepted": false,
        "lastmodified": "01-01-1900",
        "IsReporty": "0",
        "IsOnProbession": 0
    }
]
    ]*/



    }
}

