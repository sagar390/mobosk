package attendance.netsurf.netsurfattendance;

public class AttendanceStatusCurrentDay {

    /*{"EmployeeID":"160"}*/

        public static class Request {

        private String EmployeeID;

        public String getEmployeeID() {
            return EmployeeID;
        }

        public void setEmployeeID(String employeeID) {
            this.EmployeeID = employeeID;
        }





    }



    public static class Response {



        /*[
    {
       [
    {
        "IsAttendanceDone": 1
    }
]
    }
]*/

        public int getIsAttendanceDone() {
            return IsAttendanceDone;
        }

        public void setIsAttendanceDone(int isAttendanceDone) {
            this.IsAttendanceDone = isAttendanceDone;
        }

        private int IsAttendanceDone;



    }


}
