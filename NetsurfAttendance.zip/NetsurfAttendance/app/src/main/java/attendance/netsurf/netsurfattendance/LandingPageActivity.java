package attendance.netsurf.netsurfattendance;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.net.http.SslError;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.support.v7.widget.Toolbar;

import java.io.File;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;

public class LandingPageActivity extends AppCompatActivity {


    @BindView(R.id.toolbar)
    Toolbar toolbar;

    @BindView(R.id.webview)
    WebView webView;

    @BindView(R.id.name_title)
    TextView name_user;

    @BindView(R.id.emp_id)
    TextView emp_id;

    SharedPreferences pref;

    @BindView(R.id.progressBar_web)
    ProgressBar webView_progress;



    Intent intent;
    String nametoolbar;
    String status;
    String params = "";
    private float m_downX;

    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing_page);
        ButterKnife.bind(this);

        intent = getIntent();

        nametoolbar = intent.getStringExtra("Toolbar");
        status = intent.getStringExtra("status");
        pref = getApplicationContext().getSharedPreferences("Attendance", 0);
        params = intent.getStringExtra("Param");


        Typeface face = Typeface.createFromAsset(getAssets(),
                "fonts/roboto_condensed_regular.ttf");
        name_user.setTypeface(face);
        emp_id.setTypeface(face);

        name_user.setText("Welcome: " + pref.getString("Name", null));
        emp_id.setText("Emp Id : " + pref.getInt("EmployeeId", 0));

        setUpToolBar();


    //    pd = ProgressDialog.show(LandingPageActivity.this,"","Please wait..",false,false);
        pd = new ProgressDialog(LandingPageActivity.this,R.style.AppCompatAlertDialogStyle);
        pd.setTitle("Please Wait..");
        initWebView();




        if (params == null) {
            if (status.equalsIgnoreCase("one")) {

                String url = Constants.BASE_PAGE_URL_LEAVES_URL + "NewUI/RoutMe.aspx?pagename=LeaveApply&userLogin=" + pref.getString("Username", "") + "&password=" + pref.getString("Password", "");

                webView.loadUrl(url);

                Log.d("1 url", "" + url);


            } else if (status.equalsIgnoreCase("two")) {
                String url = Constants.BASE_PAGE_URL_LEAVES_URL + "NewUI/RoutMe.aspx?pagename=LeaveList&userLogin=" + pref.getString("Username", "") + "&password=" + pref.getString("Password", "");

                webView.loadUrl(url);
                Log.d("2 url", "" + url);

            } else if (status.equalsIgnoreCase("three")) {
                String url = Constants.BASE_PAGE_URL_LEAVES_URL + "NewUI/RoutMe.aspx?pagename=LeaveApprove&userLogin=" + pref.getString("Username", "") + "&password=" + pref.getString("Password", "");

                webView.loadUrl(url);
                Log.d("3 url", "" + url);


            } else if (status.equalsIgnoreCase("four"))

            {


                String url = Constants.BASE_PAGE_URL_LEAVES_URL + "NewUI/RoutMe.aspx?pagename=CompOffRequest&userLogin=" + pref.getString("Username", "") + "&password=" + pref.getString("Password", "");

                webView.loadUrl(url);

                Log.d("4 url", "" + url);


            } else if (status.equalsIgnoreCase("five")) {

                String url = Constants.BASE_PAGE_URL_LEAVES_URL + "NewUI/RoutMe.aspx?pagename=CompOffList&userLogin=" + pref.getString("Username", "") + "&password=" + pref.getString("Password", "");


                webView.loadUrl(url);
                Log.d("5 url", "" + url);

            } else if (status.equalsIgnoreCase("six"))

            {
                String url = Constants.BASE_PAGE_URL_LEAVES_URL + "NewUI/RoutMe.aspx?pagename=CompOffApprove&userLogin=" + pref.getString("Username", "") + "&password=" + pref.getString("Password", "");


                webView.loadUrl(url);

                Log.d("6 url", "" + url);
            }
         else if (status.equalsIgnoreCase("seven"))

            {
                String url = Constants.BASE_PAGE_URL_LEAVES_URL + "NewUI/RoutMe.aspx?pagename=AddTask&userLogin=" + pref.getString("Username", "") + "&password=" + pref.getString("Password", "");


                webView.loadUrl(url);

                Log.d("6 url", "" + url);
            }
       else if (status.equalsIgnoreCase("Eight"))

            {
                String url = Constants.BASE_PAGE_URL_LEAVES_URL + "NewUI/RoutMe.aspx?pagename=MedicalInsurancePolicy&userLogin=" + pref.getString("Username", "") + "&password=" + pref.getString("Password", "");


                webView.loadUrl(url);

                Log.d("6 url", "" + url);
            }
       else if (status.equalsIgnoreCase("Nine"))

            {
                String url = Constants.BASE_PAGE_URL_LEAVES_URL + "NewUI/RoutMe.aspx?pagename=ViewPolicyReadOnly&userLogin=" + pref.getString("Username", "") + "&password=" + pref.getString("Password", "");


                webView.loadUrl(url);

                Log.d("6 url", "" + url);
            }



        } else {


            webView.loadUrl(params);

            Log.d("1 ", "" + params);
        }
    }





    private void setUpToolBar() {
       // toolbar.setTitle(nametoolbar);
        //toolbar.setTitleTextColor(getResources().getColor(R.color.monsoon));
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }




    private void initWebView() {

        webView.setWebChromeClient(new MyWebChromeClient(this));

    //    webView.setInitialScale(100);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            //    webView_progress.setVisibility(View.VISIBLE);


         //     pd = new ProgressDialog(LandingPageActivity.this,R.style.AppCompatAlertDialogStyle);
                pd.show();

                invalidateOptionsMenu();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                webView.loadUrl(url);
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
            //  webView_progress.setVisibility(View.GONE);
                pd.dismiss();
                invalidateOptionsMenu();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
         //       webView_progress.setVisibility(View.GONE);
                pd.dismiss();
                invalidateOptionsMenu();
            }
        });

        webView.clearCache(true);
        webView.clearHistory();
        webView.getSettings().setJavaScriptEnabled(true);
      //  webView.setHorizontalScrollBarEnabled(false);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);


        webView.getSettings().setUseWideViewPort(true);











       // webView.getSettings().setLoadsImagesAutomatically(true);
       // webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);

//       webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        // Configure the client to use when opening URLs
        // Configure the client to use when opening URLs
        // root.web_view!!.setWebViewClient(WebViewClient())
        // root.web_view.getSettings().setUseWideViewPort(true);
        //root.web_view.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setSupportZoom(true);
        webView.getSettings().setBuiltInZoomControls(true);
        webView.getSettings().setDisplayZoomControls(true);



   /*     webView.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {

                if (event.getPointerCount() > 1) {
                    //Multi touch detected
                    return true;
                }

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN: {
                        // save the x
                        m_downX = event.getX();
                    }
                    break;

                    case MotionEvent.ACTION_MOVE:
                    case MotionEvent.ACTION_CANCEL:
                    case MotionEvent.ACTION_UP: {
                        // set x so that it doesn't move
                        event.setLocation(m_downX, event.getY());
                    }
                    break;
                }

                return false;
            }
        });*/
    }





    private class MyWebChromeClient extends WebChromeClient {
        Context context;

        public MyWebChromeClient(Context context) {
            super();
            this.context = context;
        }


    }



    @Override
    public void onResume() {
        super.onResume();
    }




    @Override
    public void onDestroy() {
        super.onDestroy();


    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }


        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        webView.destroy();
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();

    }
}
 https://payroll.netsurfnetwork.com/NewUI/AddTask.aspx&userLogin=sagar.kardak@netsurfnetwork.com&password=sagar1990

