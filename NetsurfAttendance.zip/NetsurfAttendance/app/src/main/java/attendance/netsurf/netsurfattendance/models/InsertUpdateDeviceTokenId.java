package attendance.netsurf.netsurfattendance.models;

public class InsertUpdateDeviceTokenId {



    public static class Request {

       /*Request   : {"DeviceTokenId":"dsdasdasdasdasdd","EmployeeId":"160"}
Response : [{“DeviceTokenId":"dsdasdasdasdasdd"}]*/

        private String DeviceTokenId;
        private String EmployeeId;

        public String getDeviceTokenId() {
            return DeviceTokenId;
        }

        public void setDeviceTokenId(String deviceTokenId) {
            this.DeviceTokenId = deviceTokenId;
        }

        public String getEmployeeId() {
            return EmployeeId;
        }

        public void setEmployeeId(String employeeId) {
            this.EmployeeId = employeeId;
        }
    }

    public static class Response {


        private String DeviceTokenId;

        public String getDeviceTokenId() {
            return DeviceTokenId;
        }

        public void setDeviceTokenId(String deviceTokenId) {
            this.DeviceTokenId = deviceTokenId;
        }
    }
}
